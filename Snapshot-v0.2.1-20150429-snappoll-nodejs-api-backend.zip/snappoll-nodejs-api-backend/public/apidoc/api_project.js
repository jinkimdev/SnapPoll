define({
  "title": "SnapPoll REST API",
  "url": "api",
  "order": [
    "Debug",
    "User",
    "Poll",
    "Response",
    "Result"
  ],
  "name": "snappoll-api-backend",
  "version": "0.1.3",
  "description": "SnapPoll REST API",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2015-04-27T15:18:00.144Z",
    "url": "http://apidocjs.com",
    "version": "0.12.1"
  }
});