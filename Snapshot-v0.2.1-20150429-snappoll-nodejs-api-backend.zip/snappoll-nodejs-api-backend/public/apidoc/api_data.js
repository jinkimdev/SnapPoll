define({ "api": [
  {
    "type": "get",
    "url": "/debug",
    "title": "Get test message",
    "version": "0.1.2",
    "name": "GetTest",
    "group": "Debug",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Test",
            "description": "<p>message from the API</p> "
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     <p>Hello World!</p>\n     <h1>SnapPoll API TEST</h1>\n     <h2>Current Date</h2>\n     1/1/2015\n     <h2>Current Time</h2>\n     15:23:33\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./index.js",
    "groupTitle": "Debug"
  },
  {
    "type": "post",
    "url": "/poll",
    "title": "Create a Poll",
    "version": "0.1.2",
    "name": "CreatePoll",
    "group": "Poll",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Create a new Poll with specified attributes</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "creator_id",
            "description": "<p>User id of the Poll creator</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "question",
            "description": "<p>Question text</p> "
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "active",
            "description": "<p>Specify if this Poll is active (allow Responses)</p> "
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "multiple_response_allowed",
            "description": "<p>Specify if a respondent can submit Responses more than once</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "reference_url",
            "description": "<p>Url to the image reference for this Poll</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "reference_delete_hash",
            "description": "<p>Url to the image reference delete hash (i.e. Imgur)</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "title",
            "description": "<p>Title text of this Poll</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i --data \"creatorid=userid@email.com&question=questiontest&multiple_response_allowed=true&reference_url=google.com\" http://snappoll.herokuapp.com/api/poll",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Poll",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll object</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "creator_id",
            "description": "<p>User Id of the Poll creator</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "question",
            "description": "<p>Question text</p> "
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "poll_timestamp",
            "description": "<p>Timestamp of when Poll was created</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "active",
            "description": "<p>Specify if this Poll is active (allow Responses)</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "multiple_response_allowed",
            "description": "<p>Specify if a respondent can submit Responses more than once</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "reference_url",
            "description": "<p>Url to the image reference for this Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "reference_delete_hash",
            "description": "<p>Url to the image reference delete hash needed to remove the image from image hosting (annonymous upload) (i.e. Imgur)</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "title",
            "description": "<p>Title text of this Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "open",
            "description": "<p>Specify if this poll is open (displayed to invitees)</p> "
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "attributes",
            "description": "<p>JSON format object list of attributes associated with this poll (1...n)</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attributes.attribute_id",
            "description": "<p>Id of the Attribute object</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attributes.poll_id",
            "description": "<p>Id of the Poll this Attribute belongs to</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "attributes.attribute_name",
            "description": "<p>Title of the attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "attributes.attribute_color_hex",
            "description": "<p>String value of color hex for this attribute</p> "
          }
        ]
      }
    }
  },
  {
    "type": "delete",
    "url": "/poll",
    "title": "Delete a Poll",
    "version": "0.1.2",
    "name": "DeletePoll",
    "group": "Poll",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Delete a Poll that matches specified poll_id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Integer",
            "optional": false,
            "field": "poll_id",
            "description": "<p>id of the Poll object</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i -X DELETE --data \"poll_id=1\" http://snappoll.herokuapp.com/api/poll",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Poll"
  },
  {
    "type": "get",
    "url": "/poll/invited/:user_id",
    "title": "Get invited Polls",
    "version": "0.1.2",
    "name": "GetInvitedPolls",
    "group": "Poll",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Retrieve all polls the current user has been invited to</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>id of the current user</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i http://snappoll.herokuapp.com/api/poll/invited/userid@email.com",
        "type": "json"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "polls",
            "description": "<p>Array of Poll objects</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "polls.answered_by_me",
            "description": "<p>Specify if this user has a response submitted to this poll</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "polls.poll_id",
            "description": "<p>Id of the Poll object</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.creator_id",
            "description": "<p>User Id of the Poll creator</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.question",
            "description": "<p>Question text</p> "
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "polls.poll_timestamp",
            "description": "<p>Timestamp of when Poll was created</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "polls.active",
            "description": "<p>Specify if this Poll is active (users can see)</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "polls.open",
            "description": "<p>Specify if this Poll is open for responses</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "polls.multiple_response_allowed",
            "description": "<p>Specify if a respondent can submit Responses more than once</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.reference_url",
            "description": "<p>Url to the image reference for this Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.reference_delete_hash",
            "description": "<p>Url to the image reference delete hash (i.e. Imgur)</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.title",
            "description": "<p>Title text of this Poll</p> "
          }
        ]
      }
    },
    "filename": "./index.js",
    "groupTitle": "Poll"
  },
  {
    "type": "get",
    "url": "/poll/my/:user_id",
    "title": "Get my Polls",
    "version": "0.1.2",
    "name": "GetMyPolls",
    "group": "Poll",
    "permission": [
      {
        "name": "None at the moment, should be poll creator and admin"
      }
    ],
    "description": "<p>Retrieve all polls the current user has created</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>id of the current user</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i http://snappoll.herokuapp.com/api/poll/my/userid@email.com",
        "type": "json"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "polls",
            "description": "<p>Array of Poll objects</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "polls.num_responses",
            "description": "<p>Number of responses to this poll</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "polls.poll_id",
            "description": "<p>Id of the Poll object</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.creator_id",
            "description": "<p>User Id of the Poll creator</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.question",
            "description": "<p>Question text</p> "
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "polls.poll_timestamp",
            "description": "<p>Timestamp of when Poll was created</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "polls.active",
            "description": "<p>Specify if this Poll is active (users can see)</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "polls.open",
            "description": "<p>Specify if this Poll is open for responses</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "polls.multiple_response_allowed",
            "description": "<p>Specify if a respondent can submit Responses more than once</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.reference_url",
            "description": "<p>Url to the image reference for this Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.reference_delete_hash",
            "description": "<p>Url to the image reference delete hash (i.e. Imgur)</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "polls.title",
            "description": "<p>Title text of this Poll</p> "
          }
        ]
      }
    },
    "filename": "./index.js",
    "groupTitle": "Poll"
  },
  {
    "type": "get",
    "url": "/poll/:poll_id",
    "title": "Get a Poll",
    "version": "0.1.2",
    "name": "GetPollByPollId",
    "group": "Poll",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Retrieve a Poll data specified by a poll_id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Integer",
            "optional": false,
            "field": "poll_id",
            "description": "<p>id of the Poll object</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i http://snappoll.herokuapp.com/api/poll/1",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Poll",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll object</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "creator_id",
            "description": "<p>User Id of the Poll creator</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "question",
            "description": "<p>Question text</p> "
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "poll_timestamp",
            "description": "<p>Timestamp of when Poll was created</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "active",
            "description": "<p>Specify if this Poll is active (allow Responses)</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "multiple_response_allowed",
            "description": "<p>Specify if a respondent can submit Responses more than once</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "reference_url",
            "description": "<p>Url to the image reference for this Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "reference_delete_hash",
            "description": "<p>Url to the image reference delete hash needed to remove the image from image hosting (annonymous upload) (i.e. Imgur)</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "title",
            "description": "<p>Title text of this Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "open",
            "description": "<p>Specify if this poll is open (displayed to invitees)</p> "
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "attributes",
            "description": "<p>JSON format object list of attributes associated with this poll (1...n)</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attributes.attribute_id",
            "description": "<p>Id of the Attribute object</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attributes.poll_id",
            "description": "<p>Id of the Poll this Attribute belongs to</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "attributes.attribute_name",
            "description": "<p>Title of the attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "attributes.attribute_color_hex",
            "description": "<p>String value of color hex for this attribute</p> "
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/poll/:poll_id/invites",
    "title": "Get list of friends invited to this poll",
    "version": "0.1.2",
    "name": "GetPollInvitedFriends",
    "group": "Poll",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Retrieve list of friends (Google+) invited to a Poll with specified poll_id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll</p> "
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "friends",
            "description": "<p>Array of friend Ids on Google+</p> "
          }
        ]
      }
    },
    "filename": "./index.js",
    "groupTitle": "Poll"
  },
  {
    "type": "get",
    "url": "/poll",
    "title": "Get all Polls",
    "version": "0.1.2",
    "name": "GetPolls",
    "group": "Poll",
    "permission": [
      {
        "name": "None at the moment, should be admin"
      }
    ],
    "description": "<p>Retrieve all Polls in the table</p> ",
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i http://snappoll.herokuapp.com/api/poll",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Poll",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll object</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "creator_id",
            "description": "<p>User Id of the Poll creator</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "question",
            "description": "<p>Question text</p> "
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "poll_timestamp",
            "description": "<p>Timestamp of when Poll was created</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "active",
            "description": "<p>Specify if this Poll is active (allow Responses)</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "multiple_response_allowed",
            "description": "<p>Specify if a respondent can submit Responses more than once</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "reference_url",
            "description": "<p>Url to the image reference for this Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "reference_delete_hash",
            "description": "<p>Url to the image reference delete hash needed to remove the image from image hosting (annonymous upload) (i.e. Imgur)</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "title",
            "description": "<p>Title text of this Poll</p> "
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "open",
            "description": "<p>Specify if this poll is open (displayed to invitees)</p> "
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "attributes",
            "description": "<p>JSON format object list of attributes associated with this poll (1...n)</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attributes.attribute_id",
            "description": "<p>Id of the Attribute object</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attributes.poll_id",
            "description": "<p>Id of the Poll this Attribute belongs to</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "attributes.attribute_name",
            "description": "<p>Title of the attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "attributes.attribute_color_hex",
            "description": "<p>String value of color hex for this attribute</p> "
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/poll/:poll_id/invites",
    "title": "Invite friends to a Poll",
    "version": "0.1.2",
    "name": "InviteFriendsToPoll",
    "group": "Poll",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Invite selected friends (Google+) to a Poll with specified poll_id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "friends",
            "description": "<p>Comma-separated string of current all invited friends (Google+ id)</p> "
          }
        ]
      }
    },
    "filename": "./index.js",
    "groupTitle": "Poll"
  },
  {
    "type": "post",
    "url": "/response",
    "title": "Create a Response",
    "version": "0.1.2",
    "name": "CreateResponse",
    "group": "Response",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Create a Response for a Poll with the specified poll_id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>id of Poll object</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>id of User responding to a Poll</p> "
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "x",
            "description": "<p>Integer x coordinate value of the Response</p> "
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "y",
            "description": "<p>Integer y coordinate value of the Response</p> "
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "attribute_choice",
            "description": "<p>id of the selected Attribute</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i --data \"poll_id=1&user_id=userid@email.com&x=111&y=333&attribute_choice=1\" http://snappoll.herokuapp.com/api/response",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Response",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "response_id",
            "description": "<p>Id of the Response object</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "x",
            "description": "<p>Integer x coordinate value of the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "y",
            "description": "<p>Integer y coordinate value of the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>Id of the User submitted the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attribute_choice",
            "description": "<p>Id of the selected Attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll the Response is related</p> "
          }
        ]
      }
    }
  },
  {
    "type": "delete",
    "url": "/response",
    "title": "Delete a Response",
    "version": "0.1.2",
    "name": "DeleteResponse",
    "group": "Response",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Delete a Response with the specified response_id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "response_id",
            "description": "<p>id of Response object to update</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i -X --data \"poll_id=1\" http://snappoll.herokuapp.com/api/response",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Response"
  },
  {
    "type": "get",
    "url": "/response/:response_id",
    "title": "Get a Response",
    "version": "0.1.2",
    "name": "GetResponse",
    "group": "Response",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Retrieve a Response that matches the specified response id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "response_id",
            "description": "<p>id of Response object</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i http://snappoll.herokuapp.com/api/response/1",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Response",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "response_id",
            "description": "<p>Id of the Response object</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "x",
            "description": "<p>Integer x coordinate value of the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "y",
            "description": "<p>Integer y coordinate value of the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>Id of the User submitted the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attribute_choice",
            "description": "<p>Id of the selected Attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll the Response is related</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "attribute_name",
            "description": "<p>Name of the selected Attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "attribute_color_hex",
            "description": "<p>String color of the selected Attribute in hex value</p> "
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp",
            "description": "<p>Timestamp of response submission</p> "
          }
        ]
      }
    }
  },
  {
    "type": "put",
    "url": "/response",
    "title": "Update a Response",
    "version": "0.1.2",
    "name": "UpdateResponse",
    "group": "Response",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Update a Response with the specified response_id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "response_id",
            "description": "<p>id of Response object to update</p> "
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>id of Poll object</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>id of User responding to a Poll</p> "
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "x",
            "description": "<p>Integer x coordinate value of the Response</p> "
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "y",
            "description": "<p>Integer y coordinate value of the Response</p> "
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "attribute_choice",
            "description": "<p>id of the selected Attribute</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i --data \"poll_id=1&user_id=userid@email.com&x=111&y=333&attribute_choice=1\" http://snappoll.herokuapp.com/api/response",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Response",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "response_id",
            "description": "<p>Id of the Response object</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "x",
            "description": "<p>Integer x coordinate value of the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "y",
            "description": "<p>Integer y coordinate value of the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>Id of the User submitted the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "attribute_choice",
            "description": "<p>Id of the selected Attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "poll_id",
            "description": "<p>Id of the Poll the Response is related</p> "
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/result/:poll_id",
    "title": "Get Poll Result",
    "version": "0.1.2",
    "name": "GetPollResult",
    "group": "Result",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Retrieve Responses to a Poll with the specified Poll id</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "poll_id",
            "description": "<p>id of Poll object</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i http://snappoll.herokuapp.com/api/result/1",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "Result",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "responses",
            "description": "<p>Array of Response objects</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "responses.response_id",
            "description": "<p>Id of the Response object</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "responses.x",
            "description": "<p>Integer x coordinate value of the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "responses.y",
            "description": "<p>Integer y coordinate value of the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "responses.user_id",
            "description": "<p>Id of the User submitted the Response</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "responses.poll_id",
            "description": "<p>Id of the Poll the Response is related</p> "
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "responses.timestamp",
            "description": "<p>Id of the Poll the Response is related</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "responses.attribute_choice",
            "description": "<p>Id of the selected Attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "responses.attribute_name",
            "description": "<p>Name of the selected Attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "responses.attribute_color_hex",
            "description": "<p>String color of the selected Attribute in hex value</p> "
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/result/:poll_id/stats",
    "title": "Get Poll Result Stats",
    "version": "0.1.2",
    "name": "GetPollResultStats",
    "group": "Result",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Retrieve stats of Responses (i.e. num responses per choice) to the Poll</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "poll_id",
            "description": "<p>id of Poll object</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i http://snappoll.herokuapp.com/api/result/1/stats",
        "type": "json"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "stats",
            "description": "<p>Stats of each chosen attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "stats.attribute_id",
            "description": "<p>Id of the response attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "stats.count",
            "description": "<p>Count of num responses with the chosen attribute</p> "
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "stats.poll_id",
            "description": "<p>Id of the poll that these reseponses are associated with</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "stats.attribute_name",
            "description": "<p>User input string of the attribute name</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "stats.attribute_color_hex",
            "description": "<p>Hex color in string for this attribute, ex) #FFFF00</p> "
          }
        ]
      }
    },
    "filename": "./index.js",
    "groupTitle": "Result"
  },
  {
    "type": "post",
    "url": "/user",
    "title": "Create a User",
    "version": "0.1.2",
    "name": "CreateUser",
    "group": "User",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>If first login, insert a new User, otherwise, update User</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>id of the User</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "f_name",
            "description": "<p>First name</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "l_name",
            "description": "<p>Last name</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "profile_pic_url",
            "description": "<p>Url to the profile image (i.e. Facebook or Google+)</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "gplus_id",
            "description": "<p>Google+ user id (not email address)</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i --data \"user_id=gpburdell123&f_name=George P.&l_name=Burdell&profile_pic_url=www.snappoll.com/herokuapp.com/api&gplus_id=1234567890\" http://snappoll.herokuapp.com/api/user",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "User"
  },
  {
    "type": "put",
    "url": "/user",
    "title": "Update a User",
    "version": "0.1.2",
    "name": "UpdateUser",
    "group": "User",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Update User info</p> ",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>id of the User to update</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "f_name",
            "description": "<p>First name</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "l_name",
            "description": "<p>Last name</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "profile_pic_url",
            "description": "<p>Url to the profile image (i.e. Facebook or Google+)</p> "
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "gplus_id",
            "description": "<p>Google+ user id (not email address)</p> "
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "curl -i -X PUT --data \"user_id=gpburdell123&f_name=George P.&l_name=Burdell&profile_pic_url=www.snappoll.com/herokuapp.com/api&gplus_id=1234567890\" http://snappoll.herokuapp.com/api/user",
        "type": "json"
      }
    ],
    "filename": "./index.js",
    "groupTitle": "User"
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p> "
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p> "
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./public/apidoc/main.js",
    "group": "_Users_Jin_Dropbox_Workspace_SnapPoll_snappoll_nodejs_api_backend_public_apidoc_main_js",
    "groupTitle": "_Users_Jin_Dropbox_Workspace_SnapPoll_snappoll_nodejs_api_backend_public_apidoc_main_js",
    "name": ""
  }
] });