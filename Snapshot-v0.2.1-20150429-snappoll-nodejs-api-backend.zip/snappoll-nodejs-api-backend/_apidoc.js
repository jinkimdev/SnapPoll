// -----------------------------------------------------------------------------
// General apiDoc documentation blocks and old history blocks
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Current Models
// -----------------------------------------------------------------------------

/**
 * @apiDefine ObjectPoll
 * @apiVersion 0.1.2
 *
 * @apiSuccess {Number}     poll_id         Id of the Poll object
 * @apiSuccess {String}     creator_id      User Id of the Poll creator
 * @apiSuccess {String}     question        Question text
 * @apiSuccess {Date}       poll_timestamp  Timestamp of when Poll was created
 * @apiSuccess {Boolean}    active          Specify if this Poll is active (allow Responses)         
 * @apiSuccess {Boolean}    multiple_response_allowed   Specify if a respondent can submit Responses more than once
 * @apiSuccess {String}     reference_url   Url to the image reference for this Poll
 * @apiSuccess {String}     reference_delete_hash   Url to the image reference delete hash needed to remove the image from image hosting (annonymous upload) (i.e. Imgur)
 * @apiSuccess {String}     title           Title text of this Poll
 * @apiSuccess {Boolean}    open            Specify if this poll is open (displayed to invitees)
 * @apiSuccess {Object[]}   attributes      JSON format object list of attributes associated with this poll (1...n)
 * @apiSuccess {Number}     attributes.attribute_id     Id of the Attribute object
 * @apiSuccess {Number}     attributes.poll_id          Id of the Poll this Attribute belongs to
 * @apiSuccess {String}     attributes.attribute_name   Title of the attribute
 * @apiSuccess {String}     attributes.attribute_color_hex  String value of color hex for this attribute
 */

/**
 * @apiDefine ListPoll
 * @apiVersion 0.1.2
 *
 * @apiSuccess {Object[]}   polls                 Array of Poll objects
 * @apiSuccess {Number}     polls.poll_id         Id of the Poll object
 * @apiSuccess {String}     polls.creator_id      User Id of the Poll creator
 * @apiSuccess {String}     polls.question        Question text
 * @apiSuccess {Date}       polls.poll_timestamp  Timestamp of when Poll was created
 * @apiSuccess {Boolean}    polls.active          Specify if this Poll is active (users can see)
 * @apiSuccess {Boolean}    polls.open            Specify if this Poll is open for responses
 * @apiSuccess {Boolean}    polls.multiple_response_allowed    Specify if a respondent can submit Responses more than once
 * @apiSuccess {String}     polls.reference_url   Url to the image reference for this Poll
 * @apiSuccess {String}     polls.reference_delete_hash    Url to the image reference delete hash (i.e. Imgur)
 * @apiSuccess {String}     polls.title           Title text of this Poll
 */

 /**
 * @apiDefine ObjectResponse
 * @apiVersion 0.1.2
 *
 * @apiSuccess {Number}     response_id         Id of the Response object
 * @apiSuccess {Number}     x                   Integer x coordinate value of the Response
 * @apiSuccess {Number}     y                   Integer y coordinate value of the Response
 * @apiSuccess {String}     user_id             Id of the User submitted the Response
 * @apiSuccess {Number}     attribute_choice    Id of the selected Attribute
 * @apiSuccess {Number}     poll_id             Id of the Poll the Response is related
 */

 /**
 * @apiDefine ObjectResponseWithAttribute
 * @apiVersion 0.1.2
 *
 * @apiSuccess {Number}     response_id         Id of the Response object
 * @apiSuccess {Number}     x                   Integer x coordinate value of the Response
 * @apiSuccess {Number}     y                   Integer y coordinate value of the Response
 * @apiSuccess {String}     user_id             Id of the User submitted the Response
 * @apiSuccess {Number}     attribute_choice    Id of the selected Attribute
 * @apiSuccess {Number}     poll_id             Id of the Poll the Response is related
 * @apiSuccess {String}     attribute_name      Name of the selected Attribute
 * @apiSuccess {String}     attribute_color_hex     String color of the selected Attribute in hex value
 * @apiSuccess {Timestamp}  timestamp           Timestamp of response submission
 */

/**
 * @apiDefine ListResponse
 * @apiVersion 0.1.2
 *
 * @apiSuccess {Object[]}   responses                   Array of Response objects
 * @apiSuccess {Number}     responses.response_id       Id of the Response object
 * @apiSuccess {Number}     responses.x                 Integer x coordinate value of the Response
 * @apiSuccess {Number}     responses.y                 Integer y coordinate value of the Response
 * @apiSuccess {String}     responses.user_id           Id of the User submitted the Response
 * @apiSuccess {Number}     responses.attribute_choice  Id of the selected Attribute
 * @apiSuccess {Number}     responses.poll_id           Id of the Poll the Response is related
 */

 /**
 * @apiDefine  ResultResponse
 * @apiVersion 0.1.2
 *
 * @apiSuccess {Object[]}   responses                   Array of Response objects
 * @apiSuccess {Number}     responses.response_id       Id of the Response object
 * @apiSuccess {Number}     responses.x                 Integer x coordinate value of the Response
 * @apiSuccess {Number}     responses.y                 Integer y coordinate value of the Response
 * @apiSuccess {String}     responses.user_id           Id of the User submitted the Response
 * @apiSuccess {Number}     responses.poll_id           Id of the Poll the Response is related
 * @apiSuccess {Timestamp}  responses.timestamp         Id of the Poll the Response is related
 * @apiSuccess {Number}     responses.attribute_choice  Id of the selected Attribute
 * @apiSuccess {String}     responses.attribute_name    Name of the selected Attribute
 * @apiSuccess {String}     responses.attribute_color_hex   String color of the selected Attribute in hex value
 */

// -----------------------------------------------------------------------------
 // History
// -----------------------------------------------------------------------------