var express = require('express');
var app = express();
var pg = require('pg');
var bodyParser = require('body-parser');
var router = express.Router();
var path = require('path');

// parse urlencoded request bodies into req.body
app.use(bodyParser.urlencoded({	extended: true }));
app.use(bodyParser.json());

app.set('port', (process.env.PORT || 5000));

/* allow access to static page for api documentation */
app.use(express.static(path.join(__dirname + '/public')));

var squel = require('squel');
squel.useFlavour('postgres');

// router setup
router.get('/', function(req, res, next) {
	next();
})

// when testing with local node server and local postgres db,
// enter before running node: 
// $ export DATABASE_URL=postgres:///$(whoami)
var DEBUG = 1;

// ################################################################
// ################ REST API 
// ################################################################

/* -------- DEBUG -------- */
router.get('/', function(req, res) {
	var message = '<h1>Snap Poll Rest API</h1>'
	+ '<h3>Learn more about Snap Poll Project (<a href="https://github.com/jinkim608/SnapPoll">Project GitHub page</a>)</h3>'
	+ '<h3>Learn more about this API (<a href="http://snappoll.herokuapp.com/apidoc">REST API Documentation</a>)</h3>';
	res.send(message);
	if (DEBUG) {
		console.log("DEBUG MESSAGE");
	}
});

/**
 * @api {get} /debug Get test message
 * @apiVersion 0.1.2
 * @apiName GetTest
 * @apiGroup Debug
 *
 * @apiSuccess {String} Test message from the API
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *          <p>Hello World!</p>
 *          <h1>SnapPoll API TEST</h1>
 *          <h2>Current Date</h2>
 *          1/1/2015
 *          <h2>Current Time</h2>
 *          15:23:33
 *     }
 */
router.get('/test', function(req, res) {
    var date = new Date();
    var currentHr = date.getHours();
    var currentMin = date.getMinutes();
    var message = "<p>Hello World!</p>" + "<h1>SnapPoll API TEST</h1>"
        + "<h2>Current Date</h2>" + (date.getMonth() + 1) + "/" 
        + date.getDate() + "/" + date.getFullYear()
        + "<h2>Current Time</h2>" + date.getHours() + ":" 
        + date.getMinutes() + ":" + date.getSeconds();
	res.send(message);;
});


// ----------------------------------------------------------------
// -------- POLL 
// ----------------------------------------------------------------

/**
 * @api {get} /poll Get all Polls
 * @apiVersion 0.1.2
 * @apiName GetPolls
 * @apiGroup Poll
 * @apiPermission None at the moment, should be admin
 *
 * @apiDescription Retrieve all Polls in the table
 *
 * @apiExample Example usage:
 * curl -i http://snappoll.herokuapp.com/api/poll
 *
 * @apiUse ObjectPoll
 */
router.get('/poll', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.select()
            .from('polls')
            .field('poll_id')
            .field('creator_id')
            .field('question')
            .field('poll_timestamp')
            .field('active')
            .field('multiple_response_allowed')
            .field('reference_url')
            .field('reference_delete_hash')
            .field('title')
            .order('poll_timestamp', false)
			.toString();

		console.log("#### query: " + q);

		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				res.send(result.rows);
			}
		});
	});
});

/**
 * @api {get} /poll/:poll_id Get a Poll
 * @apiVersion 0.1.2
 * @apiName GetPollByPollId
 * @apiGroup Poll
 * @apiPermission none
 *
 * @apiDescription Retrieve a Poll data specified by a poll_id
 *
 * @apiParam {Integer} poll_id id of the Poll object
 *
 * @apiExample Example usage:
 * curl -i http://snappoll.herokuapp.com/api/poll/1
 *
 * @apiUse ObjectPoll
 */
router.get('/poll/:poll_id', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.select()
            .from('polls')
            .field('poll_id')
            .field('creator_id')
            .field('question')
            .field('poll_timestamp')
            .field('active')
            .field('multiple_response_allowed')
            .field('reference_url')
            .field('reference_delete_hash')
            .field('title')
            .field('open')
            .field('(select array_to_json(array_agg(row_to_json(atr))) from (select * from attributes where attributes.poll_id = ' 
                + req.params.poll_id + ') atr) as attributes')
            .where('poll_id=' + req.params.poll_id)
            .toString();

		console.log("#### GET /poll/:poll_idquery: " + q);

		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				res.send(result.rows[0]);
			}
		});
	});
});

/**
 * @api {get} /poll/my/:user_id     Get my Polls
 * @apiVersion 0.1.2
 * @apiName GetMyPolls
 * @apiGroup Poll
 * @apiPermission None at the moment, should be poll creator and admin
 *
 * @apiDescription Retrieve all polls the current user has created
 *
 * @apiParam {String} user_id   id of the current user
 *
 * @apiExample Example usage:
 * curl -i http://snappoll.herokuapp.com/api/poll/my/userid@email.com
 *
 * @apiUse ListPoll
 * @apiSuccess  {Object[]}   polls                   Array of Poll objects
 * @apiSuccess  {Number}    polls.num_responses     Number of responses to this poll
 */
router.get('/poll/my/:user_id', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel
            .select()
            .field('polls.*')
            .field('(SELECT COUNT(response_id) from responses WHERE responses.poll_id = polls.poll_id) AS num_responses')
            .field('(SELECT array_to_json(array_agg(row_to_json(atr))) FROM (SELECT * FROM attributes WHERE attributes.poll_id = polls.poll_id) atr) AS attributes')
            .from('polls')
            .where('active = true')
            .where("creator_id = '" + req.params.user_id + "'")
            .order('poll_timestamp', false)
            .toString();

		console.log("#### query: " + q);

		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				res.send(result.rows);
			}
		});
	});
});


/**
 * @api {get} /poll/invited/:user_id     Get invited Polls
 * @apiVersion 0.1.2
 * @apiName GetInvitedPolls
 * @apiGroup Poll
 * @apiPermission none
 *
 * @apiDescription Retrieve all polls the current user has been invited to
 *
 * @apiParam {String} user_id   id of the current user
 *
 * @apiExample Example usage:
 * curl -i http://snappoll.herokuapp.com/api/poll/invited/userid@email.com
 *
 * @apiUse ListPoll
 * @apiSuccess  {Object[]}      polls                   Array of Poll objects
 * @apiSuccess  {Boolean}       polls.answered_by_me    Specify if this user has a response submitted to this poll
 */
router.get('/poll/invited/:user_id', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.select()
			.from('polls, users')
			.field('poll_id')
			.field('creator_id')
			.field('l_name AS creator_last_name')
			.field('f_name AS creator_first_name')
			.field('profile_pic_url AS creator_profile_pic_url')
			.field('title')
			.field('question')
            .field('open')
			.field('active')
			.field('reference_url')
			.field('reference_delete_hash')
            .field("EXISTS (SELECT * FROM responses WHERE responses.poll_id=polls.poll_id AND responses.user_id='" 
                + req.params.user_id + "') AS answered_by_me")
            .field('(SELECT array_to_json(array_agg(row_to_json(atr))) FROM (SELECT * FROM attributes WHERE attributes.poll_id = polls.poll_id) atr) AS attributes ')
			.where("creator_id=user_id")
			.where("creator_id<>'" + req.params.user_id + "'")
            .where('polls.open=true')
            .where("active=true")
            .order('poll_timestamp', false)
			.toString();

		console.log("#### query: " + q);

		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				res.send(result.rows);
			}
		});
	});
});

/**
 * @api {post} /poll     Create a Poll
 * @apiVersion 0.1.2
 * @apiName CreatePoll
 * @apiGroup Poll
 * @apiPermission none
 *
 * @apiDescription Create a new Poll with specified attributes
 *
 * @apiParam {String}     creator_id      User id of the Poll creator
 * @apiParam {String}     question        Question text
 * @apiParam {Boolean}    active          Specify if this Poll is active (allow Responses)         
 * @apiParam {Boolean}    multiple_response_allowed   Specify if a respondent can submit Responses more than once
 * @apiParam {String}     reference_url     Url to the image reference for this Poll
 * @apiParam {String}     [reference_delete_hash]   Url to the image reference delete hash (i.e. Imgur)
 * @apiParam {String}     [title]           Title text of this Poll
 *
 * @apiExample Example usage:
 * curl -i --data "creatorid=userid@email.com&question=questiontest&multiple_response_allowed=true&reference_url=google.com" http://snappoll.herokuapp.com/api/poll
 *
 * @apiUse ObjectPoll
 */
router.post('/poll', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
        // req params include poll data and list of attributes
        // console.log("%% req.body.attributes: " + req.body.attributes[0]);

        var currentPollId;
        var postPollResult;

        // insert poll into polls table
		var q = squel.insert().into('polls')
			.set('creator_id', req.body.creator_id)
			.set('title', req.body.title)
			.set('question', req.body.question)
			.set('multiple_response_allowed', req.body.multiple_response_allowed)
			.set('reference_url', req.body.reference_url)
			.set('reference_delete_hash', req.body.reference_delete_hash)
			.returning('*')
			.toString();

		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				console.log(" post poll result # " + result);
				console.log(" ## " + result.rows[0]);
                // remember poll id here
				// res.send(result.rows[0]);
                currentPollId = result.rows[0].poll_id;
                postPollResult = result.rows[0];

                console.log("## pollId ## " + currentPollId);

                // when inserting poll is good, insert attributes

                if (req.body.attributes) {
                    for (i = 0; i < req.body.attributes.length; i++) {
                        var attr = req.body.attributes[i];
                        console.log("##attribute_name## " + attr.attribute_name)
                        var q2 = squel.insert().into('attributes')
                            .set('poll_id', currentPollId)
                            .set('attribute_name', attr.attribute_name)
                            .set('attribute_color_hex', attr.attribute_color_hex)
                            .toString();
                        client.query(q2, function(err, result) {
                            done();
                            if (err) {
                                console.error(err);
                            } else {
                                // success
                                if (i == req.body.attributes.length - 1) {
                                    // if last one
                                }
                            }
                        });
                    } // end of inserting attributes
                }
                res.send(postPollResult);
			}
		});
	});
});

/**
 * @api {delete} /poll     Delete a Poll
 * @apiVersion 0.1.2
 * @apiName DeletePoll
 * @apiGroup Poll
 * @apiPermission none
 *
 * @apiDescription Delete a Poll that matches specified poll_id
 *
 * @apiParam {Integer} poll_id id of the Poll object
 *
 * @apiExample Example usage:
 * curl -i -X DELETE --data "poll_id=1" http://snappoll.herokuapp.com/api/poll
 */
router.delete('/poll', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.delete().from('polls')
			.where('poll_id=' + req.body.poll_id)
			.toString();
		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				// TODO: send the success message
				res.send(result.rows);
			}
		});
	});
});


/**
 * @api {get} /poll/:poll_id/invites     Get list of friends invited to this poll
 * @apiVersion 0.1.2
 * @apiName GetPollInvitedFriends
 * @apiGroup Poll
 * @apiPermission none
 *
 * @apiDescription Retrieve list of friends (Google+) invited to a Poll with specified poll_id
 *
 * @apiParam {Number}       poll_id     Id of the Poll
 *
 * @apiSuccess {Number}     poll_id     Id of the Poll
 * @apiSuccess {String[]}   friends     Array of friend Ids on Google+
 */
router.get('/poll/:poll_id/invites', function(req, res) {

    console.log("GET /poll/invite/:poll_id");

    pg.connect(process.env.DATABASE_URL, function(err, client, done) {

        var currentPollId = req.params.poll_id;
        console.log("GET invitees for Poll: " + currentPollId);

        // insert invited friends to poll_invites table
        var q = squel
            .select()
            .from('poll_invites')
            .field('poll_id')
            .field('array_agg(poll_invites.gplus_id) AS friends')
            .where("poll_id='" + currentPollId + "'")
            .group('poll_id')
            .toString();

        console.log("GET INVITES Query: " + q);

        client.query(q, function(err, result) {
            done();
            if (err) {
                console.error(err);
            }
            // console.log("## Invitees on this poll: " + result.rows[0].friends);
            res.send(result.rows[0]);
        });
    });
});

/**
 * @api {post} /poll/:poll_id/invites     Invite friends to a Poll
 * @apiVersion 0.1.2
 * @apiName InviteFriendsToPoll
 * @apiGroup Poll
 * @apiPermission none
 *
 * @apiDescription Invite selected friends (Google+) to a Poll with specified poll_id
 *
 * @apiParam {Number}   poll_id     Id of the Poll
 * @apiParam {String}   friends     Comma-separated string of current all invited friends (Google+ id)
 */
router.post('/poll/:poll_id/invites', function(req, res) {
    pg.connect(process.env.DATABASE_URL, function(err, client, done) {

        if (!req.body.friends) {
            console.log("@@## friends empty");
        }

        console.log("## IN POST INVITES");
        console.log("friends string: " + req.body.friends);

        var currentPollId = req.params.poll_id;
        var array = req.body.friends.split(',');
        var output;

        // delete old invitee list
        var q1 = squel.delete().from('poll_invites')
            .where('poll_id=' + currentPollId)
            .toString();
        client.query(q1, function(err, result) {
            done();
                if (err) {
                    console.error(err);
                } else {
                    // success

                    // if friends list empty
                    if (!req.body.friends) {
                        console.log("## Nothing to insert");
                        res.send(result.rows[0]);
                    }
                }
        });

        // if friends list not empty
        if (req.body.friends) {
            // insert invited friends to poll_invites table
            for (i = 0; i < array.length; i++) {
                var f = array[i];
                console.log("## Inserting friend ## " + f);

                var q2 = squel.insert().into('poll_invites')
                    .set('poll_id', currentPollId)
                    .set('gplus_id', f)
                    .toString();
                client.query(q2, function(err, result) {
                    done();
                    if (err) {
                        console.error(err);
                    } else {
                        // success
                        output += result.rows[0] + "\n";
                    }
                });

                res.send(output);
            } // end of inserting invited friends
        }
    });
});



// ----------------------------------------------------------------
// -------- USER 
// ----------------------------------------------------------------

/**
 * @api {post} /user     Create a User
 * @apiVersion 0.1.2
 * @apiName CreateUser
 * @apiGroup User
 * @apiPermission none
 *
 * @apiDescription If first login, insert a new User, otherwise, update User
 *
 * @apiParam {String}   user_id             id of the User
 * @apiParam {String}   f_name              First name
 * @apiParam {String}   l_name              Last name
 * @apiParam {String}   profile_pic_url     Url to the profile image (i.e. Facebook or Google+)
 * @apiParam {String}   [gplus_id]          Google+ user id (not email address)  
 *
 * @apiExample Example usage:
 * curl -i --data "user_id=gpburdell123&f_name=George P.&l_name=Burdell&profile_pic_url=www.snappoll.com/herokuapp.com/api&gplus_id=1234567890" http://snappoll.herokuapp.com/api/user
 */
router.post('/user', function(req, res) {

    console.log("##### in POST /user ## " + req.body.user_id);

	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var search = squel.select()
            .from('users')
            .field('user_id')
            .where("user_id='"+ req.body.user_id + "'")
            .toString();

        client.query(search, function(err, result) {
            done();
            if (err) {
                console.error("##### " + err + "\nQuery: " + q);
                res.send("Error: " + err + "\nQuery: " + q);

            } else {

                console.log(req);
                // first time user
                if (result.rowCount == 0) {
                    
                    console.log("\n## /user New User\n");

                    var q = squel.insert().into('users')
                        .set('user_id', req.body.user_id)
                        .set('f_name', req.body.f_name)
                        .set('l_name', req.body.l_name)
                        .set('profile_pic_url', req.body.profile_pic_url)
                        .toString();
                    client.query(q, function(err, result) {
                        done();
                        if (err) {
                            console.error(err);
                            res.send("Error: " + err + "\nQuery: " + q);
                        } else {
                            res.send(result.rows);
                        }
                    });

                // if user exists on login, update info
                } else {

                    console.log("\n## /user Returning User\n");
                    var q = squel.update().table('users')
                        .where("user_id='" + req.body.user_id + "'")
                        .set('f_name', req.body.f_name)
                        .set('l_name', req.body.l_name)
                        .set('profile_pic_url', req.body.profile_pic_url)
                        .set('gplus_id', req.body.gplus_id)
                        .toString();

                    console.log("##Query " + q);;

                    client.query(q, function(err, result) {
                        done();
                        if (err) {
                            console.error(err);
                            res.send("Error: " + err);
                        } else {
                            res.send(result.rows);
                        }
                    });
                }
            }
        })
	});
});

/**
 * @api {put} /user     Update a User
 * @apiVersion 0.1.2
 * @apiName UpdateUser
 * @apiGroup User
 * @apiPermission none
 *
 * @apiDescription      Update User info
 *
 * @apiParam {String}   user_id             id of the User to update
 * @apiParam {String}   f_name              First name
 * @apiParam {String}   l_name              Last name
 * @apiParam {String}   profile_pic_url     Url to the profile image (i.e. Facebook or Google+)
 * @apiParam {String}   [gplus_id]          Google+ user id (not email address)  
 *
 * @apiExample Example usage:
 * curl -i -X PUT --data "user_id=gpburdell123&f_name=George P.&l_name=Burdell&profile_pic_url=www.snappoll.com/herokuapp.com/api&gplus_id=1234567890" http://snappoll.herokuapp.com/api/user
 */
router.put('/user', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.update().table('users')
            .where("user_id='" + req.body.user_id + "'")
			.set('f_name', req.body.f_name)
			.set('l_name', req.body.l_name)
            .set('profile_pic_url', req.body.profile_pic_url)
            .set('gplus_id', req.body.gplus_id)
			.toString();

		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				res.send(result.rows);
			}
		});
	});
});


// ----------------------------------------------------------------
// -------- RESPONSE
// ----------------------------------------------------------------

/**
 * @api {get} /response/:response_id    Get a Response
 * @apiVersion 0.1.2
 * @apiName GetResponse
 * @apiGroup Response
 * @apiPermission none
 *
 * @apiDescription Retrieve a Response that matches the specified response id
 *
 * @apiParam {String} response_id   id of Response object
 *
 * @apiExample Example usage:
 * curl -i http://snappoll.herokuapp.com/api/response/1
 *
 * @apiUse ObjectResponseWithAttribute
 */
router.get('/response/:response_id', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.select()
            .from('responses AS r')
            .from('attributes AS a')
            .field('r.*')
            .field('a.attribute_name')
            .field('a.attribute_color_hex')
            .where('r.attribute_choice = a.attribute_id')
			.where("r.response_id='" + req.params.response_id + "'")
			.toString();
		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				res.send(result.rows[0]);
			}
		});
	});
});

/**
 * @api {post} /response    Create a Response
 * @apiVersion 0.1.2
 * @apiName CreateResponse
 * @apiGroup Response
 * @apiPermission none
 *
 * @apiDescription Create a Response for a Poll with the specified poll_id
 *
 * @apiParam {Number} poll_id   id of Poll object
 * @apiParam {String} user_id   id of User responding to a Poll
 * @apiParam {Number} x         Integer x coordinate value of the Response
 * @apiParam {Number} y         Integer y coordinate value of the Response
 * @apiParam {Number} [attribute_choice]  id of the selected Attribute
 *
 * @apiExample Example usage:
 * curl -i --data "poll_id=1&user_id=userid@email.com&x=111&y=333&attribute_choice=1" http://snappoll.herokuapp.com/api/response
 *
 * @apiUse ObjectResponse
 */
router.post('/response', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.insert().into('responses')
            .set('poll_id', req.body.poll_id)
            .set('user_id', req.body.user_id)
            .set('x', req.body.x)
            .set('y', req.body.y)
            .set('attribute_choice', req.body.attribute_choice)
            .returning('*')
			.toString();
		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
                console.log("## POST /response RESULT: " + result.rows[0]);
				res.send(result.rows[0]);
			}
		});
	});
});

/**
 * @api {put} /response    Update a Response
 * @apiVersion 0.1.2
 * @apiName UpdateResponse
 * @apiGroup Response
 * @apiPermission none
 *
 * @apiDescription Update a Response with the specified response_id
 *
 * @apiParam {Number} response_id   id of Response object to update
 * @apiParam {Number} poll_id   id of Poll object
 * @apiParam {String} user_id   id of User responding to a Poll
 * @apiParam {Number} x         Integer x coordinate value of the Response
 * @apiParam {Number} y         Integer y coordinate value of the Response
 * @apiParam {Number} [attribute_choice]  id of the selected Attribute
 *
 * @apiExample Example usage:
 * curl -i --data "poll_id=1&user_id=userid@email.com&x=111&y=333&attribute_choice=1" http://snappoll.herokuapp.com/api/response
 *
 * @apiUse ObjectResponse
 */
router.put('/response', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.update().table('responses')
            .where("response_id='" + req.body.response_id + "'")
			.set('user_id', req.body.user_id)
			.set('poll_id', req.body.poll_id)
            .set('x', req.body.x)
            .set('y', req.body.y)
            .set('attribute_choice', req.body.attribute_choice)
			.toString();

		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err + "\n" + "Query: " + q);
			} else {
				res.send(result.rows);
			}
		});
	});
});


/**
 * @api {delete} /response    Delete a Response
 * @apiVersion 0.1.2
 * @apiName DeleteResponse
 * @apiGroup Response
 * @apiPermission none
 *
 * @apiDescription Delete a Response with the specified response_id
 *
 * @apiParam {Number} response_id   id of Response object to update
 *
 * @apiExample Example usage:
 * curl -i -X --data "poll_id=1" http://snappoll.herokuapp.com/api/response
 */
router.delete('/response', function(req, res) {
    pg.connect(process.env.DATABASE_URL, function(err, client, done) {
        var q = squel.delete().from('responses')
            .where("response_id='" + req.body.response_id + "'")
            .toString();

        client.query(q, function(err, result) {
            done();
            if (err) {
                console.error(err);
                res.send("Error: " + err + "\n" + "Query: " + q);
            } else {
                res.send(result.rows);
            }
        });
    });
});


// ----------------------------------------------------------------
// -------- RESULT
// ----------------------------------------------------------------

/**
 * @api {get} /result/:poll_id    Get Poll Result
 * @apiVersion 0.1.2
 * @apiName GetPollResult
 * @apiGroup Result
 * @apiPermission none
 *
 * @apiDescription Retrieve Responses to a Poll with the specified Poll id
 *
 * @apiParam {String} poll_id   id of Poll object
 *
 * @apiExample Example usage:
 * curl -i http://snappoll.herokuapp.com/api/result/1
 *
 * @apiUse ResultResponse
 */
router.get('/result/:poll_id', function(req, res) {
	pg.connect(process.env.DATABASE_URL, function(err, client, done) {
		var q = squel.select()
            .from('responses AS r')
            .from('attributes AS a')
            .field('r.*')
            .field('a.attribute_name')
            .field('a.attribute_color_hex')
			.where('r.poll_id=' + req.params.poll_id)
            .where('r.attribute_choice = a.attribute_id')
            .order('r.timestamp', false)
			.toString();

        console.log("/result QUERY: " + q);

		client.query(q, function(err, result) {
			done();
			if (err) {
				console.error(err);
				res.send("Error: " + err);
			} else {
				res.send(result.rows);
			}
		});
	});
});

/**
 * @api {get} /result/:poll_id/stats    Get Poll Result Stats
 * @apiVersion 0.1.2
 * @apiName GetPollResultStats
 * @apiGroup Result
 * @apiPermission none
 *
 * @apiDescription Retrieve stats of Responses (i.e. num responses per choice) to the Poll
 *
 * @apiParam {String} poll_id   id of Poll object
 *
 * @apiExample Example usage:
 * curl -i http://snappoll.herokuapp.com/api/result/1/stats
 *
 * @apiSuccess  {Object[]}  stats           Stats of each chosen attribute
 * @apiSuccess  {Number}    stats.attribute_id    Id of the response attribute
 * @apiSuccess  {Number}    stats.count           Count of num responses with the chosen attribute
 * @apiSuccess  {Number}    stats.poll_id         Id of the poll that these reseponses are associated with
 * @apiSuccess  {String}    stats.attribute_name  User input string of the attribute name
 * @apiSuccess  {String}    stats.attribute_color_hex     Hex color in string for this attribute, ex) #FFFF00
 */
router.get('/result/:poll_id/stats', function(req, res) {
    pg.connect(process.env.DATABASE_URL, function(err, client, done) {
        var q = 'SELECT attribute_id,count,poll_id,attribute_name,attribute_color_hex FROM ' +
                '(SELECT attribute_choice, COUNT(response_id) ' +
                'FROM responses GROUP BY poll_id, attribute_choice ' +
                'HAVING poll_id=' + req.params.poll_id + ') ' +
                'AS r ' +
                'INNER JOIN ' +
                '(SELECT * FROM attributes) AS a '+
                'ON r.attribute_choice = a.attribute_id';

        console.log("/result QUERY: " + q);

        client.query(q, function(err, result) {
            done();
            if (err) {
                console.error(err);
                res.send("Error: " + err);
            } else {
                res.send(result.rows);
            }
        });
    });
});


/* ---------------------------------------------------------------- */

app.use('/api', router);
app.listen(app.get('port'), function() {
	console.log("Node app is running at localhost:" + app.get('port'))
});

function isEmpty(str) {
    return (!str || 0 === str.length);
}
